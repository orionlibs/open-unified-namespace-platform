package io.github.orionlibs.service1;

public class ControllerUtils
{
    public static final String baseAPIPath = "/v1";
}
