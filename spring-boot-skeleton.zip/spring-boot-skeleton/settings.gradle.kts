rootProject.name = "service1"
include("src")
